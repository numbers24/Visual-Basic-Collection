﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmFinalize
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.U = New System.Windows.Forms.Label()
        Me.P = New System.Windows.Forms.Label()
        Me.N = New System.Windows.Forms.Label()
        Me.BD = New System.Windows.Forms.Label()
        Me.C = New System.Windows.Forms.Label()
        Me.A = New System.Windows.Forms.Label()
        Me.Z = New System.Windows.Forms.Label()
        Me.btnBackIn = New System.Windows.Forms.Button()
        Me.btnBackAd = New System.Windows.Forms.Button()
        Me.btnDone = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'U
        '
        Me.U.AutoSize = True
        Me.U.Location = New System.Drawing.Point(12, 9)
        Me.U.Name = "U"
        Me.U.Size = New System.Drawing.Size(25, 13)
        Me.U.TabIndex = 0
        Me.U.Text = "lblU"
        '
        'P
        '
        Me.P.AutoSize = True
        Me.P.Location = New System.Drawing.Point(12, 36)
        Me.P.Name = "P"
        Me.P.Size = New System.Drawing.Size(24, 13)
        Me.P.TabIndex = 1
        Me.P.Text = "lblP"
        '
        'N
        '
        Me.N.AutoSize = True
        Me.N.Location = New System.Drawing.Point(12, 63)
        Me.N.Name = "N"
        Me.N.Size = New System.Drawing.Size(25, 13)
        Me.N.TabIndex = 2
        Me.N.Text = "lblN"
        '
        'BD
        '
        Me.BD.AutoSize = True
        Me.BD.Location = New System.Drawing.Point(12, 91)
        Me.BD.Name = "BD"
        Me.BD.Size = New System.Drawing.Size(32, 13)
        Me.BD.TabIndex = 3
        Me.BD.Text = "lblBD"
        '
        'C
        '
        Me.C.AutoSize = True
        Me.C.Location = New System.Drawing.Point(12, 153)
        Me.C.Name = "C"
        Me.C.Size = New System.Drawing.Size(24, 13)
        Me.C.TabIndex = 4
        Me.C.Text = "lblC"
        '
        'A
        '
        Me.A.AutoSize = True
        Me.A.Location = New System.Drawing.Point(12, 124)
        Me.A.Name = "A"
        Me.A.Size = New System.Drawing.Size(24, 13)
        Me.A.TabIndex = 5
        Me.A.Text = "lblA"
        '
        'Z
        '
        Me.Z.AutoSize = True
        Me.Z.Location = New System.Drawing.Point(12, 179)
        Me.Z.Name = "Z"
        Me.Z.Size = New System.Drawing.Size(24, 13)
        Me.Z.TabIndex = 7
        Me.Z.Text = "lblZ"
        '
        'btnBackIn
        '
        Me.btnBackIn.Location = New System.Drawing.Point(134, 82)
        Me.btnBackIn.Name = "btnBackIn"
        Me.btnBackIn.Size = New System.Drawing.Size(75, 63)
        Me.btnBackIn.TabIndex = 8
        Me.btnBackIn.Text = "Edit Username or Password"
        Me.btnBackIn.UseVisualStyleBackColor = True
        '
        'btnBackAd
        '
        Me.btnBackAd.Location = New System.Drawing.Point(134, 16)
        Me.btnBackAd.Name = "btnBackAd"
        Me.btnBackAd.Size = New System.Drawing.Size(75, 60)
        Me.btnBackAd.TabIndex = 9
        Me.btnBackAd.Text = "Edit Additional Information"
        Me.btnBackAd.UseVisualStyleBackColor = True
        '
        'btnDone
        '
        Me.btnDone.Location = New System.Drawing.Point(134, 169)
        Me.btnDone.Name = "btnDone"
        Me.btnDone.Size = New System.Drawing.Size(75, 23)
        Me.btnDone.TabIndex = 10
        Me.btnDone.Text = "Confirm"
        Me.btnDone.UseVisualStyleBackColor = True
        '
        'frmFinalize
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(247, 207)
        Me.Controls.Add(Me.btnDone)
        Me.Controls.Add(Me.btnBackAd)
        Me.Controls.Add(Me.btnBackIn)
        Me.Controls.Add(Me.Z)
        Me.Controls.Add(Me.A)
        Me.Controls.Add(Me.C)
        Me.Controls.Add(Me.BD)
        Me.Controls.Add(Me.N)
        Me.Controls.Add(Me.P)
        Me.Controls.Add(Me.U)
        Me.Name = "frmFinalize"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds
        Me.Text = "Final Confirmation"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents U As Label
    Friend WithEvents P As Label
    Friend WithEvents N As Label
    Friend WithEvents BD As Label
    Friend WithEvents C As Label
    Friend WithEvents A As Label
    Friend WithEvents Z As Label
    Friend WithEvents btnBackIn As Button
    Friend WithEvents btnBackAd As Button
    Friend WithEvents btnDone As Button
End Class

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmPay
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.txtWage = New System.Windows.Forms.TextBox()
        Me.txtHours = New System.Windows.Forms.TextBox()
        Me.lblWage = New System.Windows.Forms.Label()
        Me.lblRegular = New System.Windows.Forms.Label()
        Me.lblGross = New System.Windows.Forms.Label()
        Me.lblHours = New System.Windows.Forms.Label()
        Me.lblOverpay = New System.Windows.Forms.Label()
        Me.lblTax = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(310, 12)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 24)
        Me.btnExit.TabIndex = 0
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(310, 62)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 77)
        Me.btnCalculate.TabIndex = 1
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'txtWage
        '
        Me.txtWage.Location = New System.Drawing.Point(12, 78)
        Me.txtWage.Name = "txtWage"
        Me.txtWage.Size = New System.Drawing.Size(100, 20)
        Me.txtWage.TabIndex = 2
        '
        'txtHours
        '
        Me.txtHours.Location = New System.Drawing.Point(12, 39)
        Me.txtHours.Name = "txtHours"
        Me.txtHours.Size = New System.Drawing.Size(100, 20)
        Me.txtHours.TabIndex = 3
        '
        'lblWage
        '
        Me.lblWage.AutoSize = True
        Me.lblWage.Location = New System.Drawing.Point(12, 62)
        Me.lblWage.Name = "lblWage"
        Me.lblWage.Size = New System.Drawing.Size(62, 13)
        Me.lblWage.TabIndex = 4
        Me.lblWage.Text = "Wage Rate"
        '
        'lblRegular
        '
        Me.lblRegular.AutoSize = True
        Me.lblRegular.Location = New System.Drawing.Point(6, 101)
        Me.lblRegular.Name = "lblRegular"
        Me.lblRegular.Size = New System.Drawing.Size(65, 13)
        Me.lblRegular.TabIndex = 5
        Me.lblRegular.Text = "Regular Pay"
        '
        'lblGross
        '
        Me.lblGross.AutoSize = True
        Me.lblGross.Location = New System.Drawing.Point(9, 150)
        Me.lblGross.Name = "lblGross"
        Me.lblGross.Size = New System.Drawing.Size(55, 13)
        Me.lblGross.TabIndex = 6
        Me.lblGross.Text = "Gross Pay"
        '
        'lblHours
        '
        Me.lblHours.AutoSize = True
        Me.lblHours.Location = New System.Drawing.Point(9, 23)
        Me.lblHours.Name = "lblHours"
        Me.lblHours.Size = New System.Drawing.Size(62, 13)
        Me.lblHours.TabIndex = 7
        Me.lblHours.Text = "Total Hours"
        '
        'lblOverpay
        '
        Me.lblOverpay.AutoSize = True
        Me.lblOverpay.Location = New System.Drawing.Point(9, 126)
        Me.lblOverpay.Name = "lblOverpay"
        Me.lblOverpay.Size = New System.Drawing.Size(49, 13)
        Me.lblOverpay.TabIndex = 8
        Me.lblOverpay.Text = "Overtime"
        '
        'lblTax
        '
        Me.lblTax.AutoSize = True
        Me.lblTax.Location = New System.Drawing.Point(12, 169)
        Me.lblTax.Name = "lblTax"
        Me.lblTax.Size = New System.Drawing.Size(25, 13)
        Me.lblTax.TabIndex = 9
        Me.lblTax.Text = "Tax"
        '
        'frmPay
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(420, 191)
        Me.ControlBox = False
        Me.Controls.Add(Me.lblTax)
        Me.Controls.Add(Me.lblOverpay)
        Me.Controls.Add(Me.lblHours)
        Me.Controls.Add(Me.lblGross)
        Me.Controls.Add(Me.lblRegular)
        Me.Controls.Add(Me.lblWage)
        Me.Controls.Add(Me.txtHours)
        Me.Controls.Add(Me.txtWage)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.btnExit)
        Me.Name = "frmPay"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents btnCalculate As Button
    Friend WithEvents txtWage As TextBox
    Friend WithEvents txtHours As TextBox
    Friend WithEvents lblWage As Label
    Friend WithEvents lblRegular As Label
    Friend WithEvents lblGross As Label
    Friend WithEvents lblHours As Label
    Friend WithEvents lblOverpay As Label
    Friend WithEvents lblTax As Label
End Class

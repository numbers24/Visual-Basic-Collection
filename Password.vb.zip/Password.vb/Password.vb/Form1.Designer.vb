﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPassword
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCreate = New System.Windows.Forms.Button()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.txtPasswordRepeat = New System.Windows.Forms.TextBox()
        Me.txtUsername = New System.Windows.Forms.TextBox()
        Me.lblPassword = New System.Windows.Forms.Label()
        Me.lblUsername = New System.Windows.Forms.Label()
        Me.lblPasswordReapeat = New System.Windows.Forms.Label()
        Me.lblProfile = New System.Windows.Forms.Label()
        Me.btnContProf = New System.Windows.Forms.Button()
        Me.lblProPassword = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnCreate
        '
        Me.btnCreate.Location = New System.Drawing.Point(12, 228)
        Me.btnCreate.Name = "btnCreate"
        Me.btnCreate.Size = New System.Drawing.Size(75, 64)
        Me.btnCreate.TabIndex = 0
        Me.btnCreate.Text = "Create Profile"
        Me.btnCreate.UseVisualStyleBackColor = True
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(12, 131)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(100, 20)
        Me.txtPassword.TabIndex = 1
        Me.txtPassword.UseSystemPasswordChar = True
        '
        'txtPasswordRepeat
        '
        Me.txtPasswordRepeat.Location = New System.Drawing.Point(12, 182)
        Me.txtPasswordRepeat.Name = "txtPasswordRepeat"
        Me.txtPasswordRepeat.Size = New System.Drawing.Size(100, 20)
        Me.txtPasswordRepeat.TabIndex = 2
        Me.txtPasswordRepeat.UseSystemPasswordChar = True
        '
        'txtUsername
        '
        Me.txtUsername.Location = New System.Drawing.Point(8, 64)
        Me.txtUsername.Name = "txtUsername"
        Me.txtUsername.Size = New System.Drawing.Size(100, 20)
        Me.txtUsername.TabIndex = 3
        '
        'lblPassword
        '
        Me.lblPassword.AutoSize = True
        Me.lblPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblPassword.Location = New System.Drawing.Point(12, 113)
        Me.lblPassword.Name = "lblPassword"
        Me.lblPassword.Size = New System.Drawing.Size(98, 15)
        Me.lblPassword.TabIndex = 4
        Me.lblPassword.Text = "Create a Password"
        '
        'lblUsername
        '
        Me.lblUsername.AutoSize = True
        Me.lblUsername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblUsername.Location = New System.Drawing.Point(8, 46)
        Me.lblUsername.Name = "lblUsername"
        Me.lblUsername.Size = New System.Drawing.Size(100, 15)
        Me.lblUsername.TabIndex = 5
        Me.lblUsername.Text = "Create a Username"
        '
        'lblPasswordReapeat
        '
        Me.lblPasswordReapeat.AutoSize = True
        Me.lblPasswordReapeat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblPasswordReapeat.Location = New System.Drawing.Point(12, 164)
        Me.lblPasswordReapeat.Name = "lblPasswordReapeat"
        Me.lblPasswordReapeat.Size = New System.Drawing.Size(93, 15)
        Me.lblPasswordReapeat.TabIndex = 6
        Me.lblPasswordReapeat.Text = "Repeat Password"
        '
        'lblProfile
        '
        Me.lblProfile.AutoSize = True
        Me.lblProfile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblProfile.Location = New System.Drawing.Point(255, 69)
        Me.lblProfile.Name = "lblProfile"
        Me.lblProfile.Size = New System.Drawing.Size(41, 15)
        Me.lblProfile.TabIndex = 7
        Me.lblProfile.Text = "Label1"
        Me.lblProfile.Visible = False
        '
        'btnContProf
        '
        Me.btnContProf.Location = New System.Drawing.Point(412, 228)
        Me.btnContProf.Name = "btnContProf"
        Me.btnContProf.Size = New System.Drawing.Size(75, 64)
        Me.btnContProf.TabIndex = 8
        Me.btnContProf.Text = "Next Step"
        Me.btnContProf.UseVisualStyleBackColor = True
        Me.btnContProf.Visible = False
        '
        'lblProPassword
        '
        Me.lblProPassword.AutoSize = True
        Me.lblProPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblProPassword.Location = New System.Drawing.Point(255, 131)
        Me.lblProPassword.Name = "lblProPassword"
        Me.lblProPassword.Size = New System.Drawing.Size(41, 15)
        Me.lblProPassword.TabIndex = 9
        Me.lblProPassword.Text = "Label1"
        Me.lblProPassword.Visible = False
        '
        'frmPassword
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(499, 304)
        Me.Controls.Add(Me.lblProPassword)
        Me.Controls.Add(Me.btnContProf)
        Me.Controls.Add(Me.lblProfile)
        Me.Controls.Add(Me.lblPasswordReapeat)
        Me.Controls.Add(Me.lblUsername)
        Me.Controls.Add(Me.lblPassword)
        Me.Controls.Add(Me.txtUsername)
        Me.Controls.Add(Me.txtPasswordRepeat)
        Me.Controls.Add(Me.txtPassword)
        Me.Controls.Add(Me.btnCreate)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "frmPassword"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnCreate As Button
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents txtPasswordRepeat As TextBox
    Friend WithEvents txtUsername As TextBox
    Friend WithEvents lblPassword As Label
    Friend WithEvents lblUsername As Label
    Friend WithEvents lblPasswordReapeat As Label
    Friend WithEvents lblProfile As Label
    Friend WithEvents btnContProf As Button
    Friend WithEvents lblProPassword As Label
End Class

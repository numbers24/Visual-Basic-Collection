﻿
Microsoft Visual Studio Solution File, Format Version 12.00
# Visual Studio 14
VisualStudioVersion = 14.0.23107.0
MinimumVisualStudioVersion = 10.0.40219.1
Project("{F184B08F-C81C-45F6-A57F-5ABD9991F28F}") = "AlgorithmGenerator.vb", "AlgorithmGenerator.vb.vbproj", "{25035BA4-62E7-42DA-9443-352AA1762014}"
EndProject
Global
	GlobalSection(SolutionConfigurationPlatforms) = preSolution
		Debug|Any CPU = Debug|Any CPU
		Release|Any CPU = Release|Any CPU
	EndGlobalSection
	GlobalSection(ProjectConfigurationPlatforms) = postSolution
		{25035BA4-62E7-42DA-9443-352AA1762014}.Debug|Any CPU.ActiveCfg = Debug|Any CPU
		{25035BA4-62E7-42DA-9443-352AA1762014}.Debug|Any CPU.Build.0 = Debug|Any CPU
		{25035BA4-62E7-42DA-9443-352AA1762014}.Release|Any CPU.ActiveCfg = Release|Any CPU
		{25035BA4-62E7-42DA-9443-352AA1762014}.Release|Any CPU.Build.0 = Release|Any CPU
	EndGlobalSection
	GlobalSection(SolutionProperties) = preSolution
		HideSolutionNode = FALSE
	EndGlobalSection
EndGlobal

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmAdditional
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.imgProfile = New System.Windows.Forms.PictureBox()
        Me.txtMonth = New System.Windows.Forms.TextBox()
        Me.lblName = New System.Windows.Forms.Label()
        Me.lblBirthday = New System.Windows.Forms.Label()
        Me.txtDay = New System.Windows.Forms.TextBox()
        Me.txtYear = New System.Windows.Forms.TextBox()
        Me.lblProfPic = New System.Windows.Forms.Label()
        Me.lblBirthday1 = New System.Windows.Forms.Label()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.txtAdress = New System.Windows.Forms.TextBox()
        Me.lblAdress = New System.Windows.Forms.Label()
        Me.txtCity = New System.Windows.Forms.TextBox()
        Me.lblCity = New System.Windows.Forms.Label()
        Me.txtZip = New System.Windows.Forms.TextBox()
        Me.lblZip = New System.Windows.Forms.Label()
        Me.btnConfirm2 = New System.Windows.Forms.Button()
        Me.btnLeave = New System.Windows.Forms.Button()
        CType(Me.imgProfile, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(12, 40)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(100, 20)
        Me.txtName.TabIndex = 0
        '
        'imgProfile
        '
        Me.imgProfile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.imgProfile.Location = New System.Drawing.Point(407, 24)
        Me.imgProfile.Name = "imgProfile"
        Me.imgProfile.Size = New System.Drawing.Size(159, 141)
        Me.imgProfile.TabIndex = 1
        Me.imgProfile.TabStop = False
        '
        'txtMonth
        '
        Me.txtMonth.Location = New System.Drawing.Point(12, 133)
        Me.txtMonth.Name = "txtMonth"
        Me.txtMonth.Size = New System.Drawing.Size(24, 20)
        Me.txtMonth.TabIndex = 2
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Location = New System.Drawing.Point(12, 24)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(86, 13)
        Me.lblName.TabIndex = 3
        Me.lblName.Text = "Enter your Name"
        '
        'lblBirthday
        '
        Me.lblBirthday.AutoSize = True
        Me.lblBirthday.Location = New System.Drawing.Point(12, 117)
        Me.lblBirthday.Name = "lblBirthday"
        Me.lblBirthday.Size = New System.Drawing.Size(88, 13)
        Me.lblBirthday.TabIndex = 4
        Me.lblBirthday.Text = "Month/Day/Year"
        '
        'txtDay
        '
        Me.txtDay.Location = New System.Drawing.Point(42, 133)
        Me.txtDay.Name = "txtDay"
        Me.txtDay.Size = New System.Drawing.Size(24, 20)
        Me.txtDay.TabIndex = 5
        '
        'txtYear
        '
        Me.txtYear.Location = New System.Drawing.Point(72, 133)
        Me.txtYear.Name = "txtYear"
        Me.txtYear.Size = New System.Drawing.Size(40, 20)
        Me.txtYear.TabIndex = 6
        '
        'lblProfPic
        '
        Me.lblProfPic.AutoSize = True
        Me.lblProfPic.Location = New System.Drawing.Point(404, 8)
        Me.lblProfPic.Name = "lblProfPic"
        Me.lblProfPic.Size = New System.Drawing.Size(115, 13)
        Me.lblProfPic.TabIndex = 7
        Me.lblProfPic.Text = "Create a Profile Picture"
        '
        'lblBirthday1
        '
        Me.lblBirthday1.AutoSize = True
        Me.lblBirthday1.Location = New System.Drawing.Point(9, 90)
        Me.lblBirthday1.Name = "lblBirthday1"
        Me.lblBirthday1.Size = New System.Drawing.Size(98, 13)
        Me.lblBirthday1.TabIndex = 8
        Me.lblBirthday1.Text = "Enter Your Birthday"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'txtAdress
        '
        Me.txtAdress.Location = New System.Drawing.Point(12, 201)
        Me.txtAdress.Name = "txtAdress"
        Me.txtAdress.Size = New System.Drawing.Size(100, 20)
        Me.txtAdress.TabIndex = 9
        '
        'lblAdress
        '
        Me.lblAdress.AutoSize = True
        Me.lblAdress.Location = New System.Drawing.Point(12, 185)
        Me.lblAdress.Name = "lblAdress"
        Me.lblAdress.Size = New System.Drawing.Size(39, 13)
        Me.lblAdress.TabIndex = 10
        Me.lblAdress.Text = "Adress"
        '
        'txtCity
        '
        Me.txtCity.Location = New System.Drawing.Point(12, 251)
        Me.txtCity.Name = "txtCity"
        Me.txtCity.Size = New System.Drawing.Size(100, 20)
        Me.txtCity.TabIndex = 11
        '
        'lblCity
        '
        Me.lblCity.AutoSize = True
        Me.lblCity.Location = New System.Drawing.Point(12, 235)
        Me.lblCity.Name = "lblCity"
        Me.lblCity.Size = New System.Drawing.Size(24, 13)
        Me.lblCity.TabIndex = 12
        Me.lblCity.Text = "City"
        '
        'txtZip
        '
        Me.txtZip.Location = New System.Drawing.Point(12, 292)
        Me.txtZip.Name = "txtZip"
        Me.txtZip.Size = New System.Drawing.Size(100, 20)
        Me.txtZip.TabIndex = 13
        '
        'lblZip
        '
        Me.lblZip.AutoSize = True
        Me.lblZip.Location = New System.Drawing.Point(12, 276)
        Me.lblZip.Name = "lblZip"
        Me.lblZip.Size = New System.Drawing.Size(50, 13)
        Me.lblZip.TabIndex = 14
        Me.lblZip.Text = "Zip Code"
        '
        'btnConfirm2
        '
        Me.btnConfirm2.Location = New System.Drawing.Point(407, 201)
        Me.btnConfirm2.Name = "btnConfirm2"
        Me.btnConfirm2.Size = New System.Drawing.Size(75, 70)
        Me.btnConfirm2.TabIndex = 15
        Me.btnConfirm2.Text = "Confirm"
        Me.btnConfirm2.UseVisualStyleBackColor = True
        '
        'btnLeave
        '
        Me.btnLeave.Location = New System.Drawing.Point(501, 245)
        Me.btnLeave.Name = "btnLeave"
        Me.btnLeave.Size = New System.Drawing.Size(75, 26)
        Me.btnLeave.TabIndex = 16
        Me.btnLeave.Text = "Exit"
        Me.btnLeave.UseVisualStyleBackColor = True
        '
        'frmAdditional
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(578, 324)
        Me.Controls.Add(Me.btnLeave)
        Me.Controls.Add(Me.btnConfirm2)
        Me.Controls.Add(Me.lblZip)
        Me.Controls.Add(Me.txtZip)
        Me.Controls.Add(Me.lblCity)
        Me.Controls.Add(Me.txtCity)
        Me.Controls.Add(Me.lblAdress)
        Me.Controls.Add(Me.txtAdress)
        Me.Controls.Add(Me.lblBirthday1)
        Me.Controls.Add(Me.lblProfPic)
        Me.Controls.Add(Me.txtYear)
        Me.Controls.Add(Me.txtDay)
        Me.Controls.Add(Me.lblBirthday)
        Me.Controls.Add(Me.lblName)
        Me.Controls.Add(Me.txtMonth)
        Me.Controls.Add(Me.imgProfile)
        Me.Controls.Add(Me.txtName)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "frmAdditional"
        Me.Text = "Additional Information"
        CType(Me.imgProfile, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtName As TextBox
    Friend WithEvents imgProfile As PictureBox
    Friend WithEvents txtMonth As TextBox
    Friend WithEvents lblName As Label
    Friend WithEvents lblBirthday As Label
    Friend WithEvents txtDay As TextBox
    Friend WithEvents txtYear As TextBox
    Friend WithEvents lblProfPic As Label
    Friend WithEvents lblBirthday1 As Label
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents txtAdress As TextBox
    Friend WithEvents lblAdress As Label
    Friend WithEvents txtCity As TextBox
    Friend WithEvents lblCity As Label
    Friend WithEvents txtZip As TextBox
    Friend WithEvents lblZip As Label
    Friend WithEvents btnConfirm2 As Button
    Friend WithEvents btnLeave As Button
End Class

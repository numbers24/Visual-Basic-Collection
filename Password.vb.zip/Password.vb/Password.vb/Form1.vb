﻿Public Class frmPassword
    Private Sub frmPassword_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnCreate_Click(sender As Object, e As EventArgs) Handles btnCreate.Click
        If txtUsername.Text = "" Or txtPassword.Text = "" Then
            MessageBox.Show("Username or Password is incomplete.")
            txtPassword.Text = ""
            txtPasswordRepeat.Text = ""
            txtUsername.Text = ""

        End If
        If txtPassword.Text = txtPasswordRepeat.Text And Len(txtPasswordRepeat.Text) > 0 And Len(txtPassword.Text) > 0 Then
            lblProfile.Visible = True
            btnContProf.Visible = True
            lblProPassword.Visible = True
            lblProfile.Text = "Username: " & txtUsername.Text
            lblProPassword.Text = "Password: " & txtPassword.Text
        ElseIf txtPassword.text <> txtPasswordRepeat.Text Then
            MessageBox.Show("The Passwords do not Match. Please try again.")
            txtPassword.Text = ""
            txtPasswordRepeat.Text = ""
            txtUsername.Text = ""

        End If
    End Sub

    Private Sub lblProfile_Click(sender As Object, e As EventArgs) Handles lblProfile.Click

    End Sub

    Private Sub btnContProf_Click(sender As Object, e As EventArgs) Handles btnContProf.Click
        Me.Hide()
        frmAdditional.Show()
    End Sub
End Class
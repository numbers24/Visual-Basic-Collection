﻿Public Class frmPay
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub txtTotalHours_TextChanged(sender As Object, e As EventArgs) Handles txtHours.TextChanged

    End Sub

    Private Sub frmPay_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        If txtHours.Text <= 40 Then
            lblRegular.Text = Val(txtHours.Text) * Val(txtWage.Text)
        Else
            lblTax.Text = Val(lblGross.Text) * 0.35
            lblRegular.Text = Val(txtHours.Text) * Val(txtWage.Text)
            lblOverpay.Text = (Val(txtHours.Text) - 40) * 1.5 * Val(txtWage.Text)
            lblGross.Text = Val(txtHours.Text) * Val(txtWage.Text)
        End If
        Select Case lblGross.Text
            Case < 35000
                lblTax.Text = 0
            Case 34999.99 To 50000
                lblTax.Text = Val(lblGross.Text) * 0.28
            Case Else

        End Select
    End Sub
End Class

﻿Public Class frmAdditional
    Private Sub lblBirthday_Click(sender As Object, e As EventArgs) Handles lblBirthday.Click

    End Sub

    Private Sub imgProfile_Click(sender As Object, e As EventArgs) Handles imgProfile.Click
        Dim OpenFileDialog1 As New OpenFileDialog
        With OpenFileDialog1
            .CheckFileExists = True
            .ShowReadOnly = False
            .Filter = "All Files |*.*| Bitmap Files (*) |*.bmp;*.gif*.jpg"
            .FilterIndex = 2
            If .ShowDialog = DialogResult.OK Then
                imgProfile.Image = Image.FromFile(.FileName)
            End If
        End With



    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)


    End Sub

    Private Sub btnConfirm2_Click(sender As Object, e As EventArgs) Handles btnConfirm2.Click
        If txtAdress.Text = "" Or txtCity.Text = "" Or txtDay.Text = "" Or txtMonth.Text = "" Or txtYear.Text = "" Or txtZip.Text = "" Then
            MessageBox.Show("Process Incoplete")
        Else frmFinalize.Show()
            frmFinalize.U.Text = frmPassword.txtUsername.Text
            frmFinalize.P.Text = frmPassword.txtPassword.Text
            frmFinalize.N.Text = txtName.Text
            frmFinalize.BD.Text = txtMonth.Text And txtDay.Text And txtYear.Text
            frmFinalize.A.Text = txtAdress.Text
            frmFinalize.C.Text = txtCity.Text
            frmFinalize.Z.Text = txtZip.Text
        End If
    End Sub

    Private Sub btnLeave_Click(sender As Object, e As EventArgs) Handles btnLeave.Click
        Me.Close()
    End Sub
End Class
﻿Public Class frmFinalize
    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles P.Click

    End Sub

    Private Sub U_Click(sender As Object, e As EventArgs) Handles U.Click
        U.Text = frmPassword.txtUsername.Text
        P.Text = frmPassword.txtPassword.Text
        N.Text = frmAdditional.txtName.Text
        BD.Text = frmAdditional.txtMonth.Text And frmAdditional.txtDay.Text And frmAdditional.txtYear.Text
        A.Text = frmAdditional.txtAdress.Text
        C.Text = frmAdditional.txtCity.Text
        Z.Text = frmAdditional.txtZip.Text
    End Sub

    Private Sub btnBackAd_Click(sender As Object, e As EventArgs) Handles btnBackAd.Click
        frmAdditional.Show()
    End Sub

    Private Sub btnBackIn_Click(sender As Object, e As EventArgs) Handles btnBackIn.Click
        frmPassword.Show()
    End Sub

    Private Sub btnDone_Click(sender As Object, e As EventArgs) Handles btnDone.Click
        MessageBox.Show("Your Account has been Created!")
        frmPassword.Close()
        frmAdditional.Close()
        Me.Close()
    End Sub
End Class
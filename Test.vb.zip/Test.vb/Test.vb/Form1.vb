﻿Public Class frmBattle
    Private Sub btnEnemy_Click(sender As Object, e As EventArgs) Handles btnEnemy.Click
        If prgHealth.Value > 1 Then
            prgHealth.Value = Val(prgHealth.Value) - 1

            If prgHealth.Value = 90 Then
                btnDamage.Visible = True
            End If

            If prgHealth.Value = 50 Then
                MessageBox.Show("Your Health has Been Cut.")
                prgYourHealth.Value = 85


            End If
            If prgHealth.Value = 1 Then
                MessageBox.Show("Your Punches are too weak.")
                prgYourHealth.Value = Val(prgYourHealth.Value) - 20
                prgHealth.Value = Val(prgHealth.Value) + 35
            End If

            If prgYourHealth.Value < 45 Then
                btnHeal.Visible = True
            End If
            If prgYourHealth.Value > 50 Then
                btnHeal.Visible = False
            End If
        End If

    End Sub

    Private Sub btnDamage_Click(sender As Object, e As EventArgs) Handles btnDamage.Click
        prgHealth.Value = Val(prgHealth.Value) - 15
        btnDamage.Visible = False

    End Sub

    Private Sub btnHeal_Click(sender As Object, e As EventArgs) Handles btnHeal.Click
        prgYourHealth.Value = Val(prgYourHealth.Value) + 25

        If prgYourHealth.Value < 45 Then
            btnHeal.Visible = True
        End If
        If prgYourHealth.Value > 50 Then
            btnHeal.Visible = False
        End If
    End Sub
End Class

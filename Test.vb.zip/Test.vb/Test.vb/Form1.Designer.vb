﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBattle
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnEnemy = New System.Windows.Forms.Button()
        Me.prgHealth = New System.Windows.Forms.ProgressBar()
        Me.prgYourHealth = New System.Windows.Forms.ProgressBar()
        Me.btnDamage = New System.Windows.Forms.Button()
        Me.btnHeal = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnEnemy
        '
        Me.btnEnemy.Location = New System.Drawing.Point(229, 53)
        Me.btnEnemy.Name = "btnEnemy"
        Me.btnEnemy.Size = New System.Drawing.Size(100, 104)
        Me.btnEnemy.TabIndex = 0
        Me.btnEnemy.UseVisualStyleBackColor = True
        '
        'prgHealth
        '
        Me.prgHealth.Location = New System.Drawing.Point(229, 12)
        Me.prgHealth.Name = "prgHealth"
        Me.prgHealth.Size = New System.Drawing.Size(100, 23)
        Me.prgHealth.TabIndex = 1
        Me.prgHealth.Value = 100
        '
        'prgYourHealth
        '
        Me.prgYourHealth.Location = New System.Drawing.Point(12, 211)
        Me.prgYourHealth.Name = "prgYourHealth"
        Me.prgYourHealth.Size = New System.Drawing.Size(334, 66)
        Me.prgYourHealth.TabIndex = 2
        Me.prgYourHealth.Value = 100
        '
        'btnDamage
        '
        Me.btnDamage.Location = New System.Drawing.Point(12, 12)
        Me.btnDamage.Name = "btnDamage"
        Me.btnDamage.Size = New System.Drawing.Size(75, 71)
        Me.btnDamage.TabIndex = 3
        Me.btnDamage.Text = "Extra Damage"
        Me.btnDamage.UseVisualStyleBackColor = True
        Me.btnDamage.Visible = False
        '
        'btnHeal
        '
        Me.btnHeal.Location = New System.Drawing.Point(12, 89)
        Me.btnHeal.Name = "btnHeal"
        Me.btnHeal.Size = New System.Drawing.Size(75, 71)
        Me.btnHeal.TabIndex = 4
        Me.btnHeal.Text = "Health"
        Me.btnHeal.UseVisualStyleBackColor = True
        Me.btnHeal.Visible = False
        '
        'frmBattle
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(358, 313)
        Me.Controls.Add(Me.btnHeal)
        Me.Controls.Add(Me.btnDamage)
        Me.Controls.Add(Me.prgYourHealth)
        Me.Controls.Add(Me.prgHealth)
        Me.Controls.Add(Me.btnEnemy)
        Me.Name = "frmBattle"
        Me.Text = "Defeat the Cube"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnEnemy As Button
    Friend WithEvents prgHealth As ProgressBar
    Friend WithEvents prgYourHealth As ProgressBar
    Friend WithEvents btnDamage As Button
    Friend WithEvents btnHeal As Button
End Class
